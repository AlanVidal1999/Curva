﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Curva_Esfuerzo_Deformacion
{
    class Program
    {
        class Curva_Esfuerzo_Deformacion
        {
            private double Punto_Fluencia;
            private double Modulo_Young;
            private double Resiliencia;
            private double Resistencia_Traccion;
            private double Tenacidad;
            private double Elongacion_P;
            private double Extriccion_P;
            private double Punto_Ruptura;
            private TextReader tr;
            private List<double> Alargamiento = new List<double>();
            private List<double> Fuerza = new List<double>();
            private List<double> Deformacion_Teorica = new List<double>();
            private List<double> Deformacion_Real = new List<double>();
            private List<double> Esfuerzo_Teorico = new List<double>();
            private List<double> Esfuerzo_Real = new List<double>();
            private List<double> Limite_Elastico_Esfuerzo = new List<double>();
            private List<double> Limite_Elastico_Deformacion = new List<double>();
            public double Longitud_Inicial { get; set; }
            public double Area_Inicial { get; set; }
            public double Longitud_Final { get; set; }
            public double Area_Final { get; set; }

            public void Esfuerzo_Deformacion_Teorico()
            {
                string aux;
                using (tr = File.OpenText("Alargamiento.txt"))
                {
                    aux = tr.ReadLine();
                    while (aux != null)
                    {
                        Alargamiento.Add(Double.Parse(aux));
                        aux = tr.ReadLine();
                    }
                }
                using (tr = File.OpenText("Fuerza.txt"))
                {
                    aux = tr.ReadLine();
                    while (aux != null)
                    {
                        Fuerza.Add(Double.Parse(aux));
                        aux = tr.ReadLine();
                    }
                }
                foreach (Double L in Alargamiento)
                {
                    Deformacion_Teorica.Add((L / Longitud_Inicial));
                }
                foreach (Double F in Fuerza)
                {
                    Esfuerzo_Teorico.Add((F / Area_Inicial));
                }
            }
            public void Esfuerzo_Deformacion_Real()
            {
                double aux;
                int i = 0;
                foreach (Double d in Deformacion_Teorica)
                {
                    aux = Math.Log((d + 1));
                    Deformacion_Real.Add(aux);
                }
                foreach (Double e in Esfuerzo_Teorico)
                {
                    aux = e * (Deformacion_Teorica[i] + 1);
                    Esfuerzo_Real.Add(aux);
                    i++;
                }
            }
            public void Zona_Eslatica()
            {
                int i = 0;
                Punto_Fluencia = Deformacion_Real.Last() * 0.02;
                foreach (Double d in Deformacion_Real)
                {
                    if (d <= Punto_Fluencia)
                    {
                        Limite_Elastico_Deformacion.Add(d);
                        Limite_Elastico_Esfuerzo.Add((Esfuerzo_Real[i])); 
                    }
                    i++;
                }
            }
            public void Minimos_Cuadrados()
            {
                double SumaX = 0, SumaY = 0, SumaXY = 0, SumaX2 = 0;
                int i = 0, numero_elementos;
                foreach (Double d in Limite_Elastico_Deformacion)
                {
                    SumaX += d;
                    SumaY += Limite_Elastico_Esfuerzo[i];
                    SumaXY += (d * Limite_Elastico_Esfuerzo[i]);
                    SumaX2 += Math.Pow(d, 2);
                    i++;
                }
                numero_elementos = Limite_Elastico_Deformacion.Count();
                Modulo_Young = (numero_elementos * SumaXY - (SumaX * SumaY)) / (numero_elementos * SumaX2 - Math.Pow(SumaX, 2));
            }
            public void Datos_Caracteristicos()
            {
                int i;
                Punto_Ruptura = Esfuerzo_Real.Last();
                Resistencia_Traccion = Esfuerzo_Real.Max();
                Elongacion_P = ((Longitud_Final - Longitud_Inicial) / Longitud_Inicial) * 100;
                Extriccion_P = Math.Abs((Area_Final - Area_Inicial) / Area_Inicial) * 100;
                for (i = 1; i < Limite_Elastico_Deformacion.Count(); i++)
                {
                    Resiliencia += (((Limite_Elastico_Deformacion[i ]  - Limite_Elastico_Deformacion[i-1]) * (Limite_Elastico_Esfuerzo[i - 1] + Limite_Elastico_Esfuerzo[i])) / 2);
                }
                for (i = 1; i < Deformacion_Real.Count(); i++)
                {
                    Tenacidad += (((Deformacion_Real[i] - Deformacion_Real[i-1]) * (Esfuerzo_Real[i - 1] + Esfuerzo_Real[i])) / 2);
                }
            }
            public void Imprimir_Datos()
            {
                Console.Clear();
                Console.WriteLine("===========================================================");
                Console.WriteLine("Curva-Esfuerzo-Deformación Unitaria");
                Console.WriteLine("===========================================================");
                Console.WriteLine("Datos de Caracterización");
                Console.WriteLine("-----------------------------------------------------------");
                Console.WriteLine("Modulo de Young (MPa):                      {0}", Math.Round(Modulo_Young,2));
                Console.WriteLine();
                Console.WriteLine("Resiliencia (MPa):                          {0}", Math.Round(Resiliencia, 2));
                Console.WriteLine();
                Console.WriteLine("Tenacidad (MPa):                            {0}", Math.Round(Tenacidad, 2));
                Console.WriteLine();
                Console.WriteLine("Punto de Fluencia:                          {0}", Math.Round(Punto_Fluencia, 6));
                Console.WriteLine();
                Console.WriteLine("Resistencia a la Tracción (MPa):            {0}", Math.Round(Resistencia_Traccion, 2));
                Console.WriteLine();
                Console.WriteLine("%Elongacion:                                {0}", Math.Round(Elongacion_P, 2));
                Console.WriteLine();
                Console.WriteLine("%Extriccion:                                {0}", Math.Round(Extriccion_P, 2));
                Console.WriteLine();
                Console.WriteLine("Punto de Ruptura(MPa):                      {0}", Math.Round(Punto_Ruptura, 2));
                Console.WriteLine("-----------------------------------------------------------"); 
                Console.ReadKey();
                Console.Clear();
            }

            public void Grafica_Curva()
            {
                //Hacer la grafica de la curva
            }
        }
        static void Main()
        {
            Curva_Esfuerzo_Deformacion objCurva = new Curva_Esfuerzo_Deformacion();
            objCurva.Longitud_Inicial = 400;
            objCurva.Longitud_Final = 501;
            objCurva.Area_Inicial = 162.56;
            objCurva.Area_Final = 63;
            objCurva.Esfuerzo_Deformacion_Teorico();
            objCurva.Esfuerzo_Deformacion_Real();
            objCurva.Zona_Eslatica();
            objCurva.Minimos_Cuadrados();
            objCurva.Datos_Caracteristicos();
            objCurva.Imprimir_Datos();
        }
    }
}
